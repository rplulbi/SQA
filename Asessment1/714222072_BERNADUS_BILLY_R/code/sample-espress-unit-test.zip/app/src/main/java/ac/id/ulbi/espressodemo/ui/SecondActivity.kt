package ac.id.ulbi.espressodemo.ui

import ac.id.ulbi.espressodemo.databinding.ActivityMainBinding
import ac.id.ulbi.espressodemo.databinding.ActivitySecondBinding
import android.app.Activity
import android.os.Bundle

class SecondActivity : Activity() {
   private lateinit var binding : ActivitySecondBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySecondBinding.inflate(layoutInflater)
        setContentView(binding.root)

        with(binding) {
            btnCount.setOnClickListener {
                val count = tvCounter.text.toString().toInt()
                tvCounter.text = (count + 1).toString()
            }
        }
    }
}