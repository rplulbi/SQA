package ac.id.ulbi.espressodemo.ui.helpers

object MathHelp {
    fun add(a: Int, b: Int) = a + b
}