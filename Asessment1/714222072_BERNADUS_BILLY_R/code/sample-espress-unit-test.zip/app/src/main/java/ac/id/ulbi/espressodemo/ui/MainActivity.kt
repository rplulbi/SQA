package ac.id.ulbi.espressodemo.ui

import ac.id.ulbi.espressodemo.databinding.ActivityMainBinding
import android.app.Activity
import android.os.Bundle

class MainActivity : Activity() {
   private lateinit var binding : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}