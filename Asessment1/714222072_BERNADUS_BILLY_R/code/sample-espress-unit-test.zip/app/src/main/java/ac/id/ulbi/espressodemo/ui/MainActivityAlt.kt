package ac.id.ulbi.espressodemo.ui

import ac.id.ulbi.espressodemo.databinding.ActivityMainAltBinding
import ac.id.ulbi.espressodemo.databinding.ActivityMainBinding
import ac.id.ulbi.espressodemo.ui.helpers.MathHelp.add
import android.app.Activity
import android.os.Bundle

class MainActivityAlt : Activity() {
    private lateinit var binding: ActivityMainAltBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainAltBinding.inflate(layoutInflater)
        setContentView(binding.root)

        with(binding) {
            btnCalculate.setOnClickListener {
                val num1 = etNum1.text.toString().toInt()
                val num2 = etNum2.text.toString().toInt()
                val result = add(num1, num2)
                tvResult.text = result.toString()
            }
        }
    }
}