package ac.id.ulbi.espressodemo

import ac.id.ulbi.espressodemo.ui.helpers.MathHelp
import org.junit.Assert.assertEquals
import org.junit.Test

class AdditionUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, MathHelp.add(2, 2))
    }
}