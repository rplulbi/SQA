package ac.id.ulbi.espressodemo.ui

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.LargeTest
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.hamcrest.Matchers.allOf
import ac.id.ulbi.espressodemo.R
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import androidx.test.espresso.matcher.ViewMatchers.withParent
import androidx.test.espresso.matcher.ViewMatchers.withText

@LargeTest
@RunWith(AndroidJUnit4::class)
class SecondActivityTest {
    @Rule
    @JvmField
    var mActivityScenarioRule = ActivityScenarioRule(SecondActivity::class.java)

    @Test
    fun secondActivityTest() {
        val btnCounter = onView(
            allOf(
                withId(R.id.btnCount), withText("Count"),
                withParent(withParent(withId(android.R.id.content))),
                isDisplayed()
            )
        )
        btnCounter.perform(click())

        val textView = onView(
            allOf(
                withId(R.id.tvCounter), withText("1"),
                withParent(withParent(withId(android.R.id.content))),
                isDisplayed()
            )
        )
        textView.check(matches(withText("1")))
    }
}